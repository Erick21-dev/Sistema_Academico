package br.com.sistema.repository;

import br.com.sistema.model.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class AlunoDAO {

    public void salvar(Aluno aluno) throws SQLException {

        String sql = """
            INSERT INTO aluno
            (rgm, nome, data_nascimento, cpf, email,
             endereco, municipio, uf, celular)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getRgm());
            stmt.setString(2, aluno.getNome());
            stmt.setString(3, aluno.getDataNascimento());
            stmt.setString(4, aluno.getCpf());
            stmt.setString(5, aluno.getEmail());
            stmt.setString(6, aluno.getEndereco());
            stmt.setString(7, aluno.getMunicipio());
            stmt.setString(8, aluno.getUf());
            stmt.setString(9, aluno.getCelular());

            stmt.executeUpdate();
        }

        salvarMatricula(aluno);
    }

    private void salvarMatricula(Aluno aluno) throws SQLException {

        String sql = """
            INSERT INTO matricula
            (aluno_id, curso_id, campus_id, turno_id)
            VALUES (
                (SELECT id FROM aluno WHERE rgm = ?),
                (SELECT id FROM curso WHERE nome = ?),
                (SELECT id FROM campus WHERE nome = ?),
                (SELECT id FROM turno WHERE nome = ?)
            )
        """;

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getRgm());
            stmt.setString(2, aluno.getCurso());
            stmt.setString(3, aluno.getCampus());
            stmt.setString(4, aluno.getPeriodo());

            stmt.executeUpdate();
        }
    }
}