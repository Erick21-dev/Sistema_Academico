package br.com.sistema.repository;

import br.com.sistema.model.Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AlunoRepository {

    public void salvar(Aluno aluno) throws SQLException {
        String sql = "INSERT INTO aluno (rgm, nome, data_nascimento, cpf, email, endereco, municipio, uf, celular, curso, campus, periodo) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getRgm());
            stmt.setString(2, aluno.getNome());
            stmt.setString(3, aluno.getDataNascimento());
            stmt.setString(4, aluno.getCpf());
            stmt.setString(5, aluno.getEmail());
            stmt.setString(6, aluno.getEndereco());
            stmt.setString(7, aluno.getMunicipio());
            stmt.setString(8, aluno.getUf());
            stmt.setString(9, aluno.getCelular());
            stmt.setString(10, aluno.getCurso());
            stmt.setString(11, aluno.getCampus());
            stmt.setString(12, aluno.getPeriodo());

            stmt.executeUpdate();
        }
    }
    public void alterar(Aluno aluno) throws SQLException {
        String sql = "UPDATE aluno SET nome=?, data_nascimento=?, cpf=?, email=?, endereco=?, municipio=?, uf=?, celular=?, curso=?, campus=?, periodo=? "
                   + "WHERE rgm=?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getDataNascimento());
            stmt.setString(3, aluno.getCpf());
            stmt.setString(4, aluno.getEmail());
            stmt.setString(5, aluno.getEndereco());
            stmt.setString(6, aluno.getMunicipio());
            stmt.setString(7, aluno.getUf());
            stmt.setString(8, aluno.getCelular());
            stmt.setString(9, aluno.getCurso());
            stmt.setString(10, aluno.getCampus());
            stmt.setString(11, aluno.getPeriodo());
            stmt.setString(12, aluno.getRgm()); 

            stmt.executeUpdate();
        }
    }
    public void excluir(String rgm) throws SQLException {
        String sql = "DELETE FROM aluno WHERE rgm = ?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, rgm);
            stmt.executeUpdate();
        }
    }
    public Aluno buscarPorRgm(String rgm) throws SQLException {
        String sql = "SELECT * FROM aluno WHERE rgm = ?";
        
        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, rgm);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Aluno aluno = new Aluno();
                    aluno.setRgm(rs.getString("rgm"));
                    aluno.setNome(rs.getString("nome"));
                    aluno.setDataNascimento(rs.getString("data_nascimento"));
                    aluno.setCpf(rs.getString("cpf"));
                    aluno.setEmail(rs.getString("email"));
                    aluno.setEndereco(rs.getString("endereco"));
                    aluno.setMunicipio(rs.getString("municipio"));
                    aluno.setUf(rs.getString("uf"));
                    aluno.setCelular(rs.getString("celular"));
                    aluno.setCurso(rs.getString("curso"));
                    aluno.setCampus(rs.getString("campus"));
                    aluno.setPeriodo(rs.getString("periodo"));
                    return aluno;
                }
            }
        }
        return null;
    }
}