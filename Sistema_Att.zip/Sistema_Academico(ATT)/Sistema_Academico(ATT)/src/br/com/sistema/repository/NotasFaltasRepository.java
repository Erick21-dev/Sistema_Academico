package br.com.sistema.repository;

import br.com.sistema.model.NotasFaltas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NotasFaltasRepository {

    public void salvar(NotasFaltas notasFaltas) throws SQLException {
        String sql = "INSERT INTO notas_faltas (rgm_aluno, disciplina, semestre, nota, faltas) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, notasFaltas.getRgmAluno());
            stmt.setString(2, notasFaltas.getDisciplina());
            stmt.setString(3, notasFaltas.getSemestre());
            stmt.setDouble(4, notasFaltas.getNota());
            stmt.setInt(5, notasFaltas.getFaltas());

            stmt.executeUpdate();
        }
    }

    public void alterar(NotasFaltas notasFaltas) throws SQLException {
        String sql = "UPDATE notas_faltas SET nota = ?, faltas = ? WHERE rgm_aluno = ? AND disciplina = ? AND semestre = ?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, notasFaltas.getNota());
            stmt.setInt(2, notasFaltas.getFaltas());
            stmt.setString(3, notasFaltas.getRgmAluno());
            stmt.setString(4, notasFaltas.getDisciplina());
            stmt.setString(5, notasFaltas.getSemestre());

            stmt.executeUpdate();
        }
    }

    public void excluir(String rgm, String disciplina, String semestre) throws SQLException {
        String sql = "DELETE FROM notas_faltas WHERE rgm_aluno = ? AND disciplina = ? AND semestre = ?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, rgm);
            stmt.setString(2, disciplina);
            stmt.setString(3, semestre);

            stmt.executeUpdate();
        }
    }

    public List<NotasFaltas> listarNotasPorRgm(String rgm) throws SQLException {
        List<NotasFaltas> lista = new ArrayList<>();
        String sql = "SELECT * FROM notas_faltas WHERE rgm_aluno = ?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, rgm);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    NotasFaltas nf = new NotasFaltas();
                    nf.setId(rs.getInt("id"));
                    nf.setRgmAluno(rs.getString("rgm_aluno"));
                    nf.setDisciplina(rs.getString("disciplina"));
                    nf.setSemestre(rs.getString("semestre"));
                    nf.setNota(rs.getDouble("nota"));
                    nf.setFaltas(rs.getInt("faltas"));
                    
                    lista.add(nf);
                }
            }
        }
        return lista;
    }
}