package br.com.sistema.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoBD {

    
    private static final String URL =
        "jdbc:mysql://localhost:3306/faculdade_db?useSSL=false&serverTimezone=America/Sao_Paulo";

    private static final String USUARIO = "root";

    
    private static final String SENHA = "";

    public static Connection conectar() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL não encontrado no projeto.", e);
        }
    }
}