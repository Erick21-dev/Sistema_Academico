package br.com.sistema.view;

import br.com.sistema.model.Aluno;
import br.com.sistema.model.NotasFaltas;
import br.com.sistema.repository.AlunoRepository;
import br.com.sistema.repository.NotasFaltasRepository;

import javax.swing.*;
import javax.swing.text.MaskFormatter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.text.ParseException;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;

@SuppressWarnings("serial")
public class ViewPrincipal extends JFrame {

    //Comunicação para BD
    private AlunoRepository alunoRepo = new AlunoRepository();
    private NotasFaltasRepository notasRepo = new NotasFaltasRepository();

    //Dados Pessoais
    private JTextField txtRgm;
    private JTextField txtNome;
    private JFormattedTextField txtDataNascimento;
    private JFormattedTextField txtCpf;
    private JTextField txtEmail;
    private JTextField txtEndereco;
    private JTextField txtMunicipio;
    private JComboBox<String> cbUf;
    private JFormattedTextField txtCelular;

    //Curso
    private JComboBox<String> cbCurso;
    private JComboBox<String> cbCampus;
    private JRadioButton rbMatutino, rbVespertino, rbNoturno;
    private ButtonGroup grupoPeriodo;

    //Notas e Faltas
    private JTextField txtRgmNotas;
    private JTextField txtNomeNotas;
    private JTextField txtCursoNotas;
    private JComboBox<String> cbDisciplina;
    private JComboBox<String> cbSemestre;
    private JComboBox<String> cbNota;
    private JTextField txtFaltas;

    //Boletim
    private JTextField txtRgmBoletim;
    private JTextField txtNomeBoletim;
    private JTextField txtCursoBoletim;
    private JTable tableBoletim;
    private DefaultTableModel tableModel;

    public ViewPrincipal() {
        //Frame Principal
        setTitle("Sistema Acadêmico");
        setSize(700, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout(0, 0));

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu menuAluno = new JMenu("Aluno");
        menuBar.add(menuAluno);

        JMenuItem itemSalvar = new JMenuItem("Salvar");
        itemSalvar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
        JMenuItem itemAlterar = new JMenuItem("Alterar");
        JMenuItem itemConsultar = new JMenuItem("Consultar");
        JMenuItem itemExcluir = new JMenuItem("Excluir");
        JMenuItem itemSair = new JMenuItem("Sair");
        itemSair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.SHIFT_DOWN_MASK));

        menuAluno.add(itemSalvar);
        menuAluno.add(itemAlterar);
        menuAluno.add(itemConsultar);
        menuAluno.add(itemExcluir);
        menuAluno.addSeparator();
        menuAluno.add(itemSair);

        JMenu menuNotas = new JMenu("Notas e Faltas");
        menuBar.add(menuNotas);
        
        JMenuItem mntmNewMenuItem = new JMenuItem("Salvar");
        menuNotas.add(mntmNewMenuItem);
        
        JMenuItem mntmNewMenuItem_1 = new JMenuItem("Alterar");
        mntmNewMenuItem_1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_DOWN_MASK));
        menuNotas.add(mntmNewMenuItem_1);
        
        JMenuItem mntmNewMenuItem_2 = new JMenuItem("Excluir");
        menuNotas.add(mntmNewMenuItem_2);
        
        JMenuItem mntmNewMenuItem_3 = new JMenuItem("Consultar");
        menuNotas.add(mntmNewMenuItem_3);
        JMenu menuAjuda = new JMenu("Ajuda");
        menuBar.add(menuAjuda);
        
        JMenuItem mntmNewMenuItem_4 = new JMenuItem("Sobre");
        menuAjuda.add(mntmNewMenuItem_4);

        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        getContentPane().add(tabbedPane, BorderLayout.CENTER);

        JPanel panelDadosPessoais = new JPanel();
        panelDadosPessoais.setLayout(null);
        tabbedPane.addTab("Dados Pessoais", null, panelDadosPessoais, null);

        JLabel lblRgm = new JLabel("RGM");
        lblRgm.setBounds(20, 25, 40, 20);
        panelDadosPessoais.add(lblRgm);

        txtRgm = new JTextField();
        txtRgm.setBounds(60, 25, 120, 22);
        panelDadosPessoais.add(txtRgm);

        JLabel lblNome = new JLabel("Nome");
        lblNome.setBounds(200, 25, 40, 20);
        panelDadosPessoais.add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(240, 25, 400, 22);
        panelDadosPessoais.add(txtNome);

        JLabel lblDataNasc = new JLabel("Data de Nascimento");
        lblDataNasc.setBounds(20, 65, 120, 20);
        panelDadosPessoais.add(lblDataNasc);

        JLabel lblCpf = new JLabel("CPF");
        lblCpf.setBounds(330, 65, 40, 20);
        panelDadosPessoais.add(lblCpf);

        JLabel lblEmail = new JLabel("Email");
        lblEmail.setBounds(20, 105, 40, 20);
        panelDadosPessoais.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(60, 105, 580, 22);
        panelDadosPessoais.add(txtEmail);

        JLabel lblEnd = new JLabel("End.");
        lblEnd.setBounds(20, 145, 40, 20);
        panelDadosPessoais.add(lblEnd);

        txtEndereco = new JTextField();
        txtEndereco.setBounds(60, 145, 580, 22);
        panelDadosPessoais.add(txtEndereco);

        JLabel lblMunicipio = new JLabel("Município");
        lblMunicipio.setBounds(20, 185, 60, 20);
        panelDadosPessoais.add(lblMunicipio);

        txtMunicipio = new JTextField();
        txtMunicipio.setBounds(85, 185, 180, 22);
        panelDadosPessoais.add(txtMunicipio);

        JLabel lblUf = new JLabel("UF");
        lblUf.setBounds(280, 185, 20, 20);
        panelDadosPessoais.add(lblUf);

        String[] ufs = {"SP", "RJ", "MG", "PR", "SC", "RS"};
        cbUf = new JComboBox<>(ufs);
        cbUf.setBounds(310, 185, 60, 22);
        panelDadosPessoais.add(cbUf);

        JLabel lblCelular = new JLabel("Celular");
        lblCelular.setBounds(390, 185, 50, 20);
        panelDadosPessoais.add(lblCelular);

        try {
            MaskFormatter mascaraData = new MaskFormatter("##/##/####");
            txtDataNascimento = new JFormattedTextField(mascaraData);
            txtDataNascimento.setBounds(150, 65, 120, 22);
            panelDadosPessoais.add(txtDataNascimento);

            MaskFormatter mascaraCpf = new MaskFormatter("###.###.###-##");
            txtCpf = new JFormattedTextField(mascaraCpf);
            txtCpf.setBounds(370, 65, 150, 22);
            panelDadosPessoais.add(txtCpf);

            MaskFormatter mascaraCelular = new MaskFormatter("(##)#####-####");
            txtCelular = new JFormattedTextField(mascaraCelular);
            txtCelular.setBounds(440, 185, 150, 22);
            panelDadosPessoais.add(txtCelular);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        JPanel panelCurso = new JPanel();
        panelCurso.setLayout(null);
        tabbedPane.addTab("Curso", null, panelCurso, null);

        JLabel lblCurso = new JLabel("Curso");
        lblCurso.setBounds(20, 30, 60, 20);
        panelCurso.add(lblCurso);

        String[] cursos = {"Análise e Desenvolvimento de Sistemas", "Ciência da Computação", "Engenharia de Software"};
        cbCurso = new JComboBox<>(cursos);
        cbCurso.setBounds(90, 30, 400, 22);
        panelCurso.add(cbCurso);

        JLabel lblCampus = new JLabel("Campus");
        lblCampus.setBounds(20, 70, 60, 20);
        panelCurso.add(lblCampus);

        String[] campi = {"Tatuapé", "Anália Franco", "Pinheiros"};
        cbCampus = new JComboBox<>(campi);
        cbCampus.setBounds(90, 70, 250, 22);
        panelCurso.add(cbCampus);

        JLabel lblPeriodo = new JLabel("Período");
        lblPeriodo.setBounds(20, 110, 60, 20);
        panelCurso.add(lblPeriodo);

        rbMatutino = new JRadioButton("Matutino");
        rbMatutino.setBounds(90, 110, 90, 20);
        panelCurso.add(rbMatutino);

        rbVespertino = new JRadioButton("Vespertino");
        rbVespertino.setBounds(190, 110, 100, 20);
        panelCurso.add(rbVespertino);

        rbNoturno = new JRadioButton("Noturno");
        rbNoturno.setSelected(true);
        rbNoturno.setBounds(300, 110, 90, 20);
        panelCurso.add(rbNoturno);

        grupoPeriodo = new ButtonGroup();
        grupoPeriodo.add(rbMatutino);
        grupoPeriodo.add(rbVespertino);
        grupoPeriodo.add(rbNoturno);
        
        JButton btnSair = new JButton();
        btnSair.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.exit(0);
        	}
        });
        btnSair.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\botao-de-energia.png"));
        btnSair.setBounds(20, 182, 75, 65);
        panelCurso.add(btnSair);
        
        JButton btnSalvar = new JButton();
        btnSalvar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
        		    Aluno aluno = new Aluno(
        		        txtRgm.getText(),
        		        txtNome.getText(),
        		        converterData(txtDataNascimento.getText().trim()),
        		        txtCpf.getText(),
        		        txtEmail.getText(),
        		        txtEndereco.getText(),
        		        txtMunicipio.getText(),
        		        cbUf.getSelectedItem().toString(),
        		        txtCelular.getText(),
        		        cbCurso.getSelectedItem().toString(),
        		        cbCampus.getSelectedItem().toString(),
        		        obterPeriodoSelecionado()
        		    );

        		    AlunoRepository repository = new AlunoRepository();
        		    repository.salvar(aluno);

        		    javax.swing.JOptionPane.showMessageDialog(
        		        null,
        		        "Aluno salvo com sucesso!"
        		    );

        		} catch (Exception ex) {
        		    javax.swing.JOptionPane.showMessageDialog(
        		        null,
        		        "Erro ao salvar: " + ex.getMessage()
        		    );
        		    ex.printStackTrace();
        		}
        	}
        });
        btnSalvar.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\Papirus-Team-Papirus-Places-Folder-teal-java.64.png"));
        btnSalvar.setBounds(141, 182, 75, 65);
        panelCurso.add(btnSalvar);
        
        JButton btnConsultar = new JButton();
        btnConsultar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 try {
        	            String rgm = txtRgm.getText().trim();

        	            if (rgm.isEmpty()) {
        	                JOptionPane.showMessageDialog(
        	                    ViewPrincipal.this,
        	                    "Informe o RGM para consultar."
        	                );
        	                return;
        	            }

        	            Aluno aluno = alunoRepo.buscarPorRgm(rgm);

        	            if (aluno != null) {
        	                txtNome.setText(aluno.getNome());
        	                txtDataNascimento.setText(aluno.getDataNascimento());
        	                txtCpf.setText(aluno.getCpf());
        	                txtEmail.setText(aluno.getEmail());
        	                txtEndereco.setText(aluno.getEndereco());
        	                txtMunicipio.setText(aluno.getMunicipio());
        	                cbUf.setSelectedItem(aluno.getUf());
        	                txtCelular.setText(aluno.getCelular());

        	                cbCurso.setSelectedItem(aluno.getCurso());
        	                cbCampus.setSelectedItem(aluno.getCampus());

        	                if ("Matutino".equals(aluno.getPeriodo())) {
        	                    rbMatutino.setSelected(true);
        	                } else if ("Vespertino".equals(aluno.getPeriodo())) {
        	                    rbVespertino.setSelected(true);
        	                } else {
        	                    rbNoturno.setSelected(true);
        	                }

        	                JOptionPane.showMessageDialog(
        	                    ViewPrincipal.this,
        	                    "Aluno encontrado com sucesso!"
        	                );
        	            } else {
        	                JOptionPane.showMessageDialog(
        	                    ViewPrincipal.this,
        	                    "Aluno não encontrado."
        	                );
        	            }

        	        } catch (Exception ex) {
        	            JOptionPane.showMessageDialog(
        	                ViewPrincipal.this,
        	                "Erro ao consultar: " + ex.getMessage()
        	            );
        	            ex.printStackTrace();
        	        }
        	}
        });
        btnConsultar.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\blue_coffee_2_folder_12398.png"));
        btnConsultar.setBounds(265, 182, 75, 65);
        panelCurso.add(btnConsultar);
        
        JButton btnAlterar = new JButton();
        btnAlterar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
                    Aluno aluno = new Aluno(
                        txtRgm.getText().trim(),
                        txtNome.getText().trim(),
                        converterData(txtDataNascimento.getText().trim()),
                        txtCpf.getText().trim(),
                        txtEmail.getText().trim(),
                        txtEndereco.getText().trim(),
                        txtMunicipio.getText().trim(),
                        cbUf.getSelectedItem().toString(),
                        txtCelular.getText().trim(),
                        cbCurso.getSelectedItem().toString(),
                        cbCampus.getSelectedItem().toString(),
                        obterPeriodoSelecionado()
                    );

                    alunoRepo.alterar(aluno);

                    JOptionPane.showMessageDialog(
                        ViewPrincipal.this,
                        "Aluno alterado com sucesso!"
                    );

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                        ViewPrincipal.this,
                        "Erro ao alterar: " + ex.getMessage()
                    );
                    ex.printStackTrace();
                }
        	}
        });
        btnAlterar.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\jar.png"));
        btnAlterar.setBounds(384, 182, 75, 65);
        panelCurso.add(btnAlterar);
        
        JButton btnExcluir = new JButton();
        btnExcluir.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
                    String rgm = txtRgm.getText().trim();

                    if (rgm.isEmpty()) {
                        JOptionPane.showMessageDialog(
                            ViewPrincipal.this,
                            "Informe o RGM para excluir."
                        );
                        return;
                    }

                    int opcao = JOptionPane.showConfirmDialog(
                        ViewPrincipal.this,
                        "Deseja realmente excluir este aluno?",
                        "Confirmação",
                        JOptionPane.YES_NO_OPTION
                    );

                    if (opcao == JOptionPane.YES_OPTION) {
                        alunoRepo.excluir(rgm);

                        JOptionPane.showMessageDialog(
                            ViewPrincipal.this,
                            "Aluno excluído com sucesso!"
                        );

                        // Limpa os campos
                        txtRgm.setText("");
                        txtNome.setText("");
                        txtDataNascimento.setText("");
                        txtCpf.setText("");
                        txtEmail.setText("");
                        txtEndereco.setText("");
                        txtMunicipio.setText("");
                        cbUf.setSelectedIndex(0);
                        txtCelular.setText("");
                        cbCurso.setSelectedIndex(0);
                        cbCampus.setSelectedIndex(0);
                        rbNoturno.setSelected(true);
                    }

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                        ViewPrincipal.this,
                        "Erro ao excluir: " + ex.getMessage()
                    );
                    ex.printStackTrace();
                }
        	}
        });
        btnExcluir.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\java.png"));
        btnExcluir.setBounds(534, 182, 75, 65);
        panelCurso.add(btnExcluir);

        //Notas e Faltas
        JPanel panelNotasFaltas = new JPanel();
        panelNotasFaltas.setLayout(null);
        tabbedPane.addTab("Notas e Faltas", null, panelNotasFaltas, null);

        JLabel lblRgmNotas = new JLabel("RGM");
        lblRgmNotas.setBounds(20, 25, 40, 20);
        panelNotasFaltas.add(lblRgmNotas);

        txtRgmNotas = new JTextField();
        txtRgmNotas.setBounds(60, 25, 120, 25);
        panelNotasFaltas.add(txtRgmNotas);

        txtNomeNotas = new JTextField("");
        txtNomeNotas.setEditable(false);
        txtNomeNotas.setBounds(190, 25, 440, 25);
        panelNotasFaltas.add(txtNomeNotas);

        txtCursoNotas = new JTextField("");
        txtCursoNotas.setEditable(false);
        txtCursoNotas.setBounds(20, 60, 610, 25);
        panelNotasFaltas.add(txtCursoNotas);

        JLabel lblDisciplina = new JLabel("Disciplina");
        lblDisciplina.setBounds(20, 100, 70, 20);
        panelNotasFaltas.add(lblDisciplina);

        String[] disciplinas = {"Programação Orientada a Objetos", "Estrutura de Dados", "Banco de Dados"};
        cbDisciplina = new JComboBox<>(disciplinas);
        cbDisciplina.setBounds(90, 100, 540, 25);
        panelNotasFaltas.add(cbDisciplina);

        JLabel lblSemestre = new JLabel("Semestre");
        lblSemestre.setBounds(20, 140, 60, 20);
        panelNotasFaltas.add(lblSemestre);

        String[] semestres = {"2020-1", "2020-2", "2026-1", "2026-2"};
        cbSemestre = new JComboBox<>(semestres);
        cbSemestre.setBounds(90, 140, 90, 25);
        panelNotasFaltas.add(cbSemestre);

        JLabel lblNota = new JLabel("Nota");
        lblNota.setBounds(200, 140, 40, 20);
        panelNotasFaltas.add(lblNota);

        String[] notas = {"0,0", "0,5", "1,0", "5,0", "7,0", "10,0"};
        cbNota = new JComboBox<>(notas);
        cbNota.setBounds(240, 140, 70, 25);
        panelNotasFaltas.add(cbNota);

        JLabel lblFaltas = new JLabel("Faltas");
        lblFaltas.setBounds(330, 140, 40, 20);
        panelNotasFaltas.add(lblFaltas);

        txtFaltas = new JTextField();
        txtFaltas.setBounds(380, 140, 80, 25);
        panelNotasFaltas.add(txtFaltas);

        int larguraBotao = 75;
        int alturaBotao = 65;
        int posicaoYBotao = 190;

        JButton btnSalvarNota = new JButton();
        btnSalvarNota.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\Papirus-Team-Papirus-Places-Folder-teal-java.64.png"));
        btnSalvarNota.setBounds(40, 190, larguraBotao, alturaBotao);
        panelNotasFaltas.add(btnSalvarNota);

        JButton btnAlterarNota = new JButton();
        btnAlterarNota.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\blue_coffee_2_folder_12398.png"));
        btnAlterarNota.setBounds(130, posicaoYBotao, larguraBotao, alturaBotao);
        panelNotasFaltas.add(btnAlterarNota);

        JButton btnConsultarNota = new JButton();
        btnConsultarNota.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\jar.png"));
        btnConsultarNota.setBounds(220, posicaoYBotao, larguraBotao, alturaBotao);
        panelNotasFaltas.add(btnConsultarNota);

        JButton btnExcluirNota = new JButton();
        btnExcluirNota.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\java.png"));
        btnExcluirNota.setBounds(310, posicaoYBotao, larguraBotao, alturaBotao);
        panelNotasFaltas.add(btnExcluirNota);

        JButton btnSairNota = new JButton();
        btnSairNota.setIcon(new ImageIcon("C:\\Users\\erick\\Downloads\\botao-de-energia.png"));
        btnSairNota.setBounds(400, posicaoYBotao, larguraBotao, alturaBotao);
        panelNotasFaltas.add(btnSairNota);

        //Boletim
        
        JPanel panelBoletim = new JPanel();
        panelBoletim.setLayout(null);
        tabbedPane.addTab("Boletim", null, panelBoletim, null);

        JLabel lblRgmBoletim = new JLabel("RGM");
        lblRgmBoletim.setBounds(20, 20, 40, 20);
        panelBoletim.add(lblRgmBoletim);

        txtRgmBoletim = new JTextField();
        txtRgmBoletim.setBounds(60, 20, 120, 25);
        panelBoletim.add(txtRgmBoletim);

        JButton btnGerarBoletim = new JButton("Gerar Boletim");
        btnGerarBoletim.setBounds(190, 19, 130, 26);
        panelBoletim.add(btnGerarBoletim);

        JLabel lblNomeBoletim = new JLabel("Nome:");
        lblNomeBoletim.setBounds(20, 55, 50, 20);
        panelBoletim.add(lblNomeBoletim);

        txtNomeBoletim = new JTextField();
        txtNomeBoletim.setEditable(false);
        txtNomeBoletim.setBounds(70, 55, 550, 25);
        panelBoletim.add(txtNomeBoletim);

        JLabel lblCursoBoletim = new JLabel("Curso:");
        lblCursoBoletim.setBounds(20, 90, 50, 20);
        panelBoletim.add(lblCursoBoletim);

        txtCursoBoletim = new JTextField();
        txtCursoBoletim.setEditable(false);
        txtCursoBoletim.setBounds(70, 90, 550, 25);
        panelBoletim.add(txtCursoBoletim);

        String[] colunas = {"Disciplina", "Semestre", "Nota", "Faltas"};
        tableModel = new DefaultTableModel(colunas, 0);
        tableBoletim = new JTable(tableModel);
        
        JScrollPane scrollPane = new JScrollPane(tableBoletim);
        scrollPane.setBounds(20, 130, 600, 220);
        panelBoletim.add(scrollPane);

        txtRgmNotas.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent evt) {
                try {
                    String rgm = txtRgmNotas.getText().trim();
                    if (!rgm.isEmpty()) {
                        Aluno aluno = alunoRepo.buscarPorRgm(rgm);
                        if (aluno != null) {
                            txtNomeNotas.setText(aluno.getNome());
                            txtCursoNotas.setText(aluno.getCurso());
                        } else {
                            JOptionPane.showMessageDialog(null, "RGM não cadastrado!");
                            txtNomeNotas.setText("deverá mostrar o nome do aluno");
                            txtCursoNotas.setText("deverá mostrar o curso do aluno");
                        }
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao buscar aluno: " + ex.getMessage());
                }
            }
        });

        btnSalvarNota.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	try {
                    String rgm = txtRgmNotas.getText().trim();
                    if (txtNomeNotas.getText().equals("deverá mostrar o nome do aluno") || rgm.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Busque um aluno válido antes de salvar.");
                        return;
                    }

                    NotasFaltas nf = new NotasFaltas();
                    nf.setRgmAluno(rgm);
                    nf.setDisciplina(cbDisciplina.getSelectedItem().toString());
                    nf.setSemestre(cbSemestre.getSelectedItem().toString());
                    
                    String notaStr = cbNota.getSelectedItem().toString().replace(",", ".");
                    nf.setNota(Double.parseDouble(notaStr));
                    nf.setFaltas(Integer.parseInt(txtFaltas.getText().trim()));

                    notasRepo.salvar(nf);
                    JOptionPane.showMessageDialog(null, "Nota cadastrada com sucesso!");
                    txtFaltas.setText("");
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(null, "Insira um número inteiro válido em Faltas.");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao salvar nota: " + ex.getMessage());
                }
            }
        });

        btnAlterarNota.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    NotasFaltas nf = new NotasFaltas();
                    nf.setRgmAluno(txtRgmNotas.getText().trim());
                    nf.setDisciplina(cbDisciplina.getSelectedItem().toString());
                    nf.setSemestre(cbSemestre.getSelectedItem().toString());
                    
                    String notaStr = cbNota.getSelectedItem().toString().replace(",", ".");
                    nf.setNota(Double.parseDouble(notaStr));
                    nf.setFaltas(Integer.parseInt(txtFaltas.getText().trim()));

                    notasRepo.alterar(nf);
                    JOptionPane.showMessageDialog(null, "Histórico alterado com sucesso!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao alterar nota: " + ex.getMessage());
                }
            }
        });

        btnExcluirNota.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String rgm = txtRgmNotas.getText().trim();
                    String disc = cbDisciplina.getSelectedItem().toString();
                    String sem = cbSemestre.getSelectedItem().toString();

                    int confirmacao = JOptionPane.showConfirmDialog(null, "Deseja excluir a nota de " + disc + "?", "Aviso", JOptionPane.YES_NO_OPTION);
                    if (confirmacao == JOptionPane.YES_OPTION) {
                        notasRepo.excluir(rgm, disc, sem);
                        JOptionPane.showMessageDialog(null, "Registro de nota removido.");
                        txtFaltas.setText("");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao excluir nota: " + ex.getMessage());
                }
            }
        });

        btnGerarBoletim.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String rgm = txtRgmBoletim.getText().trim();
                    if (rgm.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Insira o RGM para o boletim.");
                        return;
                    }

                    Aluno aluno = alunoRepo.buscarPorRgm(rgm);
                    if (aluno != null) {
                        txtNomeBoletim.setText(aluno.getNome());
                        txtCursoBoletim.setText(aluno.getCurso());
                        
                        tableModel.setRowCount(0); // Reseta a tabela
                        java.util.List<NotasFaltas> historico = notasRepo.listarNotasPorRgm(rgm);
                        
                        for (NotasFaltas nf : historico) {
                            Object[] linha = {
                                nf.getDisciplina(),
                                nf.getSemestre(),
                                String.valueOf(nf.getNota()).replace(".", ","),
                                nf.getFaltas()
                            };
                            tableModel.addRow(linha);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Aluno não encontrado!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao gerar boletim: " + ex.getMessage());
                }
            }
        });

        ActionListener acaoConsultarAluno = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String rgm = txtRgm.getText().trim();
                    Aluno aluno = alunoRepo.buscarPorRgm(rgm);
                    if (aluno != null) {
                        txtNome.setText(aluno.getNome());
                        txtDataNascimento.setText(aluno.getDataNascimento());
                        txtCpf.setText(aluno.getCpf());
                        txtEmail.setText(aluno.getEmail());
                        txtEndereco.setText(aluno.getEndereco());
                        txtMunicipio.setText(aluno.getMunicipio());
                        cbUf.setSelectedItem(aluno.getUf());
                        txtCelular.setText(aluno.getCelular());
                        cbCurso.setSelectedItem(aluno.getCurso());
                        cbCampus.setSelectedItem(aluno.getCampus());
                        
                        if ("Matutino".equals(aluno.getPeriodo())) rbMatutino.setSelected(true);
                        else if ("Vespertino".equals(aluno.getPeriodo())) rbVespertino.setSelected(true);
                        else rbNoturno.setSelected(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Aluno não encontrado!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao consultar aluno: " + ex.getMessage());
                }
            }
        };
        itemConsultar.addActionListener(acaoConsultarAluno);
        btnConsultarNota.addActionListener(acaoConsultarAluno);

        itemSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Aluno a = new Aluno();
                    a.setRgm(txtRgm.getText());
                    a.setNome(txtNome.getText());
                    a.setDataNascimento(txtDataNascimento.getText());
                    a.setCpf(txtCpf.getText());
                    a.setEmail(txtEmail.getText());
                    a.setEndereco(txtEndereco.getText());
                    a.setMunicipio(txtMunicipio.getText());
                    a.setUf(cbUf.getSelectedItem().toString());
                    a.setCelular(txtCelular.getText());
                    a.setCurso(cbCurso.getSelectedItem().toString());
                    a.setCampus(cbCampus.getSelectedItem().toString());
                    
                    if (rbMatutino.isSelected()) a.setPeriodo("Matutino");
                    else if (rbVespertino.isSelected()) a.setPeriodo("Vespertino");
                    else a.setPeriodo("Noturno");

                    alunoRepo.salvar(a);
                    JOptionPane.showMessageDialog(null, "Aluno cadastrado com sucesso!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao salvar aluno: " + ex.getMessage());
                }
            }
        });

        itemSair.addActionListener(e -> System.exit(0));
        btnSairNota.addActionListener(e -> System.exit(0));
    }
    private String obterPeriodoSelecionado() {
        if (rbMatutino.isSelected()) {
            return "Matutino";
        } else if (rbVespertino.isSelected()) {
            return "Vespertino";
        } else if (rbNoturno.isSelected()) {
            return "Noturno";
        }
        return "";
    }
    private String converterData(String dataBr) {
        String[] partes = dataBr.split("/");
        if (partes.length == 3) {
            return partes[2] + "-" + partes[1] + "-" + partes[0];
        }
        return dataBr;
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ViewPrincipal frame = new ViewPrincipal();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}