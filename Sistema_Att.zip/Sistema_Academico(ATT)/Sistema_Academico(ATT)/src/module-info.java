/**
 * 
 */
/**
 * 
 */
module SistemaAcademico {
	requires java.desktop;
	requires java.sql;
}